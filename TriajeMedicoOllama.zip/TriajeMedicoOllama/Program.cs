﻿using System;
using System.Text;
using System.Text.Json;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TriajeMedicoOllama
{
    class Program
    {
        private static readonly string ollamaUrl = "http://localhost:11434/api/generate";
        private static readonly string modelName = "llama3";

        static async Task Main(string[] args)
        {
            Console.Clear();
            Console.Title = "Sistema Hospitalario de Triaje IA - UFHEC";

            // Encabezado Principal
            DibujarEncabezado();

            // 1. Captura de Datos Personales
            DibujarSeccion("1. REGISTRO DE DATOS DEL PACIENTE");

            Console.Write("  ▸ Nombre(s): ");
            string nombre = Console.ReadLine();

            Console.Write("  ▸ Apellido(s): ");
            string apellido = Console.ReadLine();

            // Captura y Validación de Cédula Dominicana
            string cedula = SolicitarCedula();

            // Captura y Validación de Edad
            int edad = SolicitarEdad();

            // 2. Captura del Motivo de Consulta
            Console.WriteLine();
            DibujarSeccion("2. EVALUACIÓN CLÍNICA Y SÍNTOMAS");

            Console.WriteLine("  Escriba en detalle el relato o los síntomas presentados por el paciente:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("  ▸ ");
            string sintomas = Console.ReadLine();
            Console.ResetColor();

            // 3. Procesamiento
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("  [⏳] Enviando datos al modelo local de IA (Ollama)... Por favor espere.");
            Console.ResetColor();

            string promptTemplate = $@"
[SISTEMA DE TRIAJE MÉDICO AUTOMATIZADO]
Eres un asistente experto en triaje hospitalario de emergencias. Tu objetivo es analizar el relato de síntomas de un paciente, clasificar la urgencia médica y derivar a la especialidad correspondiente.

INSTRUCCIONES DE RAZONAMIENTO (Chain of Thought):
1. Evalúa los síntomas proporcionados y busca signos de alarma vital.
2. Determina el Nivel de Urgencia (ROJO, AMARILLO, VERDE).
3. Selecciona la Especialidad Médica entre: [Cardiología, Neurología, Medicina General, Traumatología, Pediatría, Gastroenterología, Neumología].
4. Genera una breve justificación clínica de la decisión.

FORMATO DE SALIDA REQUERIDO:
Responde ÚNICAMENTE en este formato JSON exacto:
{{
  ""razonamiento"": ""<analisis paso a paso de los sintomas>"",
  ""nivel_urgencia"": ""<ROJO | AMARILLO | VERDE>"",
  ""especialidad"": ""<especialidad medica>"",
  ""justificacion"": ""<justificacion clinica breve>""
}}

DATOS DEL PACIENTE:
Nombre Completo: {nombre} {apellido}
Cédula: {cedula}
Edad: {edad} años
Síntomas descritos: ""{sintomas}""
";

            string respuestaJson = await ConsultarOllamaAsync(promptTemplate);

            if (!string.IsNullOrEmpty(respuestaJson))
            {
                MostrarResultadoElegante(nombre, apellido, cedula, edad, respuestaJson);
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n  [❌] ERROR: No se pudo obtener respuesta de Ollama.");
                Console.WriteLine("      Asegúrate de que Ollama esté ejecutándose en segundo plano.");
                Console.ResetColor();
            }

            Console.WriteLine("\n  Presione cualquier tecla para salir del sistema...");
            Console.ReadKey();
        }

        #region Métodos de Interfaz y Validación

        private static void DibujarEncabezado()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("╔══════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                 CENTRO MÉDICO / SISTEMA DE TRIAJE INTELIGENTE                    ║");
            Console.WriteLine("║                      Integración con IA Local                                    ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            Console.WriteLine();
        }

        private static void DibujarSeccion(string titulo)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"┌── {titulo} " + new string('─', 78 - titulo.Length - 4) + "┐");
            Console.ResetColor();
        }

        private static string SolicitarCedula()
        {
            while (true)
            {
                Console.Write("  ▸ Cédula de Identidad (11 dígitos): ");
                string entrada = Console.ReadLine() ?? "";

                // Remover guiones o espacios
                string cedulaLimpia = Regex.Replace(entrada, @"[^\d]", "");

                if (cedulaLimpia.Length == 11)
                {
                    // Retornar en formato 000-0000000-0
                    return $"{cedulaLimpia.Substring(0, 3)}-{cedulaLimpia.Substring(3, 7)}-{cedulaLimpia.Substring(10, 1)}";
                }

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("     [!] Cédula inválida. Debe contener exactamente 11 dígitos numéricos.");
                Console.ResetColor();
            }
        }

        private static int SolicitarEdad()
        {
            while (true)
            {
                Console.Write("  ▸ Edad (años): ");
                if (int.TryParse(Console.ReadLine(), out int edad) && edad >= 0 && edad <= 120)
                {
                    return edad;
                }

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("     [!] Edad inválida. Ingrese un valor numérico correcto.");
                Console.ResetColor();
            }
        }

        #endregion

        #region Conexión HTTP

        private static async Task<string> ConsultarOllamaAsync(string promptText)
        {
            using (HttpClient client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(5);

                var requestBody = new
                {
                    model = modelName,
                    prompt = promptText,
                    stream = false
                };

                string jsonPayload = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                try
                {
                    HttpResponseMessage response = await client.PostAsync(ollamaUrl, content);
                    response.EnsureSuccessStatusCode();

                    string responseString = await response.Content.ReadAsStringAsync();

                    using (JsonDocument doc = JsonDocument.Parse(responseString))
                    {
                        return doc.RootElement.GetProperty("response").GetString();
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"\n  [Excepción] Error al conectar con Ollama: {ex.Message}");
                    Console.ResetColor();
                    return null;
                }
            }
        }

        #endregion

        #region Renderizado de Resultados

        private static void MostrarResultadoElegante(string nombre, string apellido, string cedula, int edad, string resultadoRaw)
        {
            Console.Clear();
            DibujarEncabezado();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("╔══════════════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                           DICTAMEN OFICIAL DE TRIAJE                             ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();

            // Muestra de Datos Personales
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine($"  PACIENTE: {nombre.ToUpper()} {apellido.ToUpper()}  |  CÉDULA: {cedula}  |  EDAD: {edad} años");
            Console.WriteLine(new string('─', 82));
            Console.ResetColor();

            try
            {
                using (JsonDocument jsonDoc = JsonDocument.Parse(resultadoRaw))
                {
                    var root = jsonDoc.RootElement;
                    string nivel = root.GetProperty("nivel_urgencia").GetString().ToUpper();
                    string especialidad = root.GetProperty("especialidad").GetString();
                    string razonamiento = root.GetProperty("razonamiento").GetString();
                    string justificacion = root.GetProperty("justificacion").GetString();

                    // Muestra visual del Nivel
                    Console.Write("  NIVEL DE PRIORIDAD MÉDICA: ");
                    if (nivel.Contains("ROJO"))
                    {
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("  [ 🔴 CÓDIGO ROJO - EMERGENCIA VITAL ]  ");
                    }
                    else if (nivel.Contains("AMARILLO"))
                    {
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.WriteLine("  [ 🟡 CÓDIGO AMARILLO - URGENCIA ALTA ]  ");
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("  [ 🟢 CÓDIGO VERDE - CONSULTA GENERAL ]  ");
                    }
                    Console.ResetColor();

                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"  ✚ ESPECIALIDAD RECOMENDADA : {especialidad}");
                    Console.ResetColor();

                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("  📋 JUSTIFICACIÓN CLÍNICA:");
                    Console.ResetColor();
                    Console.WriteLine($"     {justificacion}");

                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("  🧠 RAZONAMIENTO ANALÍTICO (Chain of Thought):");
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine($"     {razonamiento}");
                    Console.ResetColor();

                    Console.WriteLine("\n" + new string('═', 82));
                }
            }
            catch
            {
                Console.WriteLine("\n  Respuesta directa del modelo:");
                Console.WriteLine(resultadoRaw);
            }
        }

        #endregion
    }
}